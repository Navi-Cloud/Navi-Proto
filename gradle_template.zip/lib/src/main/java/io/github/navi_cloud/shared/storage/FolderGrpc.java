package io.github.navi_cloud.shared.storage;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Service Description
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.40.1)",
    comments = "Source: StorageService/FolderService.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class FolderGrpc {

  private FolderGrpc() {}

  public static final String SERVICE_NAME = "io.github.navi_cloud.shared.storage.Folder";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest,
      io.github.navi_cloud.shared.CommonCommunication.Result> getCreateRootFolderMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateRootFolder",
      requestType = io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest.class,
      responseType = io.github.navi_cloud.shared.CommonCommunication.Result.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest,
      io.github.navi_cloud.shared.CommonCommunication.Result> getCreateRootFolderMethod() {
    io.grpc.MethodDescriptor<io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest, io.github.navi_cloud.shared.CommonCommunication.Result> getCreateRootFolderMethod;
    if ((getCreateRootFolderMethod = FolderGrpc.getCreateRootFolderMethod) == null) {
      synchronized (FolderGrpc.class) {
        if ((getCreateRootFolderMethod = FolderGrpc.getCreateRootFolderMethod) == null) {
          FolderGrpc.getCreateRootFolderMethod = getCreateRootFolderMethod =
              io.grpc.MethodDescriptor.<io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest, io.github.navi_cloud.shared.CommonCommunication.Result>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateRootFolder"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.github.navi_cloud.shared.CommonCommunication.Result.getDefaultInstance()))
              .setSchemaDescriptor(new FolderMethodDescriptorSupplier("CreateRootFolder"))
              .build();
        }
      }
    }
    return getCreateRootFolderMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest,
      io.github.navi_cloud.shared.CommonCommunication.Result> getFindInsideFilesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "FindInsideFiles",
      requestType = io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest.class,
      responseType = io.github.navi_cloud.shared.CommonCommunication.Result.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest,
      io.github.navi_cloud.shared.CommonCommunication.Result> getFindInsideFilesMethod() {
    io.grpc.MethodDescriptor<io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest, io.github.navi_cloud.shared.CommonCommunication.Result> getFindInsideFilesMethod;
    if ((getFindInsideFilesMethod = FolderGrpc.getFindInsideFilesMethod) == null) {
      synchronized (FolderGrpc.class) {
        if ((getFindInsideFilesMethod = FolderGrpc.getFindInsideFilesMethod) == null) {
          FolderGrpc.getFindInsideFilesMethod = getFindInsideFilesMethod =
              io.grpc.MethodDescriptor.<io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest, io.github.navi_cloud.shared.CommonCommunication.Result>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "FindInsideFiles"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.github.navi_cloud.shared.CommonCommunication.Result.getDefaultInstance()))
              .setSchemaDescriptor(new FolderMethodDescriptorSupplier("FindInsideFiles"))
              .build();
        }
      }
    }
    return getFindInsideFilesMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static FolderStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<FolderStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<FolderStub>() {
        @java.lang.Override
        public FolderStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new FolderStub(channel, callOptions);
        }
      };
    return FolderStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static FolderBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<FolderBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<FolderBlockingStub>() {
        @java.lang.Override
        public FolderBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new FolderBlockingStub(channel, callOptions);
        }
      };
    return FolderBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static FolderFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<FolderFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<FolderFutureStub>() {
        @java.lang.Override
        public FolderFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new FolderFutureStub(channel, callOptions);
        }
      };
    return FolderFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Service Description
   * </pre>
   */
  public static abstract class FolderImplBase implements io.grpc.BindableService {

    /**
     */
    public void createRootFolder(io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest request,
        io.grpc.stub.StreamObserver<io.github.navi_cloud.shared.CommonCommunication.Result> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateRootFolderMethod(), responseObserver);
    }

    /**
     */
    public void findInsideFiles(io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest request,
        io.grpc.stub.StreamObserver<io.github.navi_cloud.shared.CommonCommunication.Result> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getFindInsideFilesMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getCreateRootFolderMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest,
                io.github.navi_cloud.shared.CommonCommunication.Result>(
                  this, METHODID_CREATE_ROOT_FOLDER)))
          .addMethod(
            getFindInsideFilesMethod(),
            io.grpc.stub.ServerCalls.asyncUnaryCall(
              new MethodHandlers<
                io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest,
                io.github.navi_cloud.shared.CommonCommunication.Result>(
                  this, METHODID_FIND_INSIDE_FILES)))
          .build();
    }
  }

  /**
   * <pre>
   * Service Description
   * </pre>
   */
  public static final class FolderStub extends io.grpc.stub.AbstractAsyncStub<FolderStub> {
    private FolderStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FolderStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new FolderStub(channel, callOptions);
    }

    /**
     */
    public void createRootFolder(io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest request,
        io.grpc.stub.StreamObserver<io.github.navi_cloud.shared.CommonCommunication.Result> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateRootFolderMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void findInsideFiles(io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest request,
        io.grpc.stub.StreamObserver<io.github.navi_cloud.shared.CommonCommunication.Result> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getFindInsideFilesMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * Service Description
   * </pre>
   */
  public static final class FolderBlockingStub extends io.grpc.stub.AbstractBlockingStub<FolderBlockingStub> {
    private FolderBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FolderBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new FolderBlockingStub(channel, callOptions);
    }

    /**
     */
    public io.github.navi_cloud.shared.CommonCommunication.Result createRootFolder(io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateRootFolderMethod(), getCallOptions(), request);
    }

    /**
     */
    public io.github.navi_cloud.shared.CommonCommunication.Result findInsideFiles(io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getFindInsideFilesMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * Service Description
   * </pre>
   */
  public static final class FolderFutureStub extends io.grpc.stub.AbstractFutureStub<FolderFutureStub> {
    private FolderFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FolderFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new FolderFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<io.github.navi_cloud.shared.CommonCommunication.Result> createRootFolder(
        io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateRootFolderMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<io.github.navi_cloud.shared.CommonCommunication.Result> findInsideFiles(
        io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getFindInsideFilesMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_ROOT_FOLDER = 0;
  private static final int METHODID_FIND_INSIDE_FILES = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final FolderImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(FolderImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_ROOT_FOLDER:
          serviceImpl.createRootFolder((io.github.navi_cloud.shared.storage.StorageMessage.CreateRootFolderRequest) request,
              (io.grpc.stub.StreamObserver<io.github.navi_cloud.shared.CommonCommunication.Result>) responseObserver);
          break;
        case METHODID_FIND_INSIDE_FILES:
          serviceImpl.findInsideFiles((io.github.navi_cloud.shared.storage.StorageMessage.FindInsideFilesRequest) request,
              (io.grpc.stub.StreamObserver<io.github.navi_cloud.shared.CommonCommunication.Result>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class FolderBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    FolderBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return io.github.navi_cloud.shared.storage.FolderService.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("Folder");
    }
  }

  private static final class FolderFileDescriptorSupplier
      extends FolderBaseDescriptorSupplier {
    FolderFileDescriptorSupplier() {}
  }

  private static final class FolderMethodDescriptorSupplier
      extends FolderBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    FolderMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (FolderGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new FolderFileDescriptorSupplier())
              .addMethod(getCreateRootFolderMethod())
              .addMethod(getFindInsideFilesMethod())
              .build();
        }
      }
    }
    return result;
  }
}
